#!/bin/bash
# ─────────────────────────────────────────────────────────────────
# SMKWIK BDM Platform — GitHub Push Script
# Run this once from inside the smkr-power-partner-platform folder
# ─────────────────────────────────────────────────────────────────

set -e

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   SMKWIK BDM Platform — GitHub Deployment Setup     ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── STEP 1: Init git if not already a repo
if [ ! -d ".git" ]; then
  echo "▶ Initializing git repository..."
  git init
  echo "  ✓ Git initialized"
else
  echo "▶ Git repo already exists — skipping init"
fi

# ── STEP 2: Stage all files
echo ""
echo "▶ Staging all files..."
git add .
echo "  ✓ All files staged"

# ── STEP 3: Commit
echo ""
echo "▶ Creating commit..."
git commit -m "feat: add BDM document hub with insurance L&L, speaker scripts, and Power Partners agenda

- Insurance Agent L&L (17-slide animated HTML presentation)
- Speaker scripts for Dan Falese, Brandon Bynum, Ben Krejcarek
- Power Partners Weekly session agenda with QR code
- BDM Document Hub landing page at /docs/
- Updated vercel.json to route static docs alongside React app
- All documents print to legal-size PDF from browser"

echo "  ✓ Commit created"

# ── STEP 4: Set branch to main
echo ""
echo "▶ Setting branch to main..."
git branch -M main
echo "  ✓ Branch set to main"

# ── STEP 5: Instructions for remote
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   FINAL STEP — Run this command:                     ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "  Replace YOUR_GITHUB_USERNAME and YOUR_REPO_NAME below:"
echo ""
echo "  git remote add origin https://github.com/YOUR_GITHUB_USERNAME/smkr-power-partner-platform.git"
echo "  git push -u origin main"
echo ""
echo "  If the remote already exists (repo was cloned):"
echo ""
echo "  git push origin main"
echo ""
echo "  ✓ Once pushed, Vercel will auto-deploy."
echo "  ✓ Your docs will be live at:"
echo "     https://your-vercel-url.vercel.app/docs/"
echo ""
echo "────────────────────────────────────────────────────────"
echo "  Document URLs after deploy:"
echo ""
echo "  /docs/                        → Document Hub"
echo "  /docs/insurance-ll.html       → Insurance L&L Presentation"
echo "  /docs/script-dan.html         → Dan Falese Script"
echo "  /docs/script-brandon.html     → Brandon Bynum Script"
echo "  /docs/script-ben.html         → Ben Krejcarek Script"
echo "  /docs/power-partners-agenda.html → PP Weekly Agenda"
echo "────────────────────────────────────────────────────────"
echo ""

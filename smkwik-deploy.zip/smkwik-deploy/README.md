# SMKR Power Partner Platform

BDM operating hub for ServiceMaster KWIK Restore — Gurnee, Cary, Sturtevant, and Hartford territories.

Deployed on Vercel. Built with Vite + React.

---

## What's In This Repo

### React App (`/src`)
The BDM operating hub — contacts, invites, follow-ups, touchpoints, metrics, expenses, ops requests, and surveys. Powered by Google Sheets via Apps Script.

### BDM Document Hub (`/public/docs`)
Static HTML documents accessible at `/docs/` — no build step required. All documents print to legal-size PDF from the browser.

| File | URL | Description |
|------|-----|-------------|
| `index.html` | `/docs/` | Document hub landing page |
| `insurance-ll.html` | `/docs/insurance-ll.html` | Insurance Agent L&L — 17-slide animated presentation |
| `script-dan.html` | `/docs/script-dan.html` | Speaker script — Dan Falese |
| `script-brandon.html` | `/docs/script-brandon.html` | Speaker script — Brandon Bynum |
| `script-ben.html` | `/docs/script-ben.html` | Speaker script — Ben Krejcarek |
| `power-partners-agenda.html` | `/docs/power-partners-agenda.html` | Power Partners Weekly session agenda |

---

## Deploy

### First-time setup

1. Clone this repo
2. Create the Google Sheet using `apps-script/Code.gs` → run `setupSheet()`
3. Deploy Apps Script as a Web App (Execute as: Me, Access: Anyone)
4. Copy the Web App URL
5. Add it as an environment variable in Vercel:
   ```
   VITE_APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_ID/exec
   ```
6. Push to GitHub → Vercel auto-deploys

### Local development

```bash
npm install
npm run dev
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `VITE_APPS_SCRIPT_URL` | Google Apps Script Web App URL |

---

## Adding New Documents

To add a new document to the hub:

1. Drop the HTML file into `/public/docs/`
2. Add a card for it in `/public/docs/index.html`
3. Push — Vercel deploys automatically

---

## Repo Structure

```
smkr-power-partner-platform/
├── public/
│   ├── docs/
│   │   ├── index.html              ← Document hub
│   │   ├── insurance-ll.html       ← Insurance L&L presentation
│   │   ├── script-dan.html         ← Dan Falese speaker script
│   │   ├── script-brandon.html     ← Brandon Bynum speaker script
│   │   ├── script-ben.html         ← Ben Krejcarek speaker script
│   │   └── power-partners-agenda.html ← PP Weekly agenda
│   └── assets/
│       └── GURNEE_QR_CODE.png
├── src/
│   ├── main.jsx                    ← React app entry
│   └── styles.css
├── apps-script/
│   └── Code.gs                     ← Google Sheets setup
├── index.html                      ← Vite entry point
├── package.json
├── vercel.json                     ← Routing config
└── .gitignore
```

---

## Team

| Name | Role | Email | Phone |
|------|------|-------|-------|
| Dan Falese | Director of Business Development | danf@smkwik.com | 630-768-6950 |
| Brandon Bynum | BDM · Gurnee & Cary | brandon@smkwik.com | 979-637-8453 |
| Ben Krejcarek | BDM · Sturtevant & Hartford | benk@smkwik.com | 920-217-0431 |

**ServiceMaster KWIK Restore** · www.smkwik.com · Found. Chosen. Remembered.
